package com.ipath.parser;

import com.ipath.parser.math.Comparison;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class MapParsingService
{
    //Public Constants
    
    public static final int MAX_ZOOM_LEVEL_DEFAULT = 3;
    public static final int MAX_X_DEFAULT = 3;
    public static final int MAX_Y_DEFAULT = 3;
    
    //Private Fields
    
    private static int MAX_ZOOM_LEVEL;
    private static int MAX_X;
    private static int MAX_Y;
    private static Tile MAP=null;
    private static BoundingBox CUSTOM_BOUNDING_BOX=null;
    
    //Public Functions
    
    public static void serializeParsedMap(String serialized_file) throws IOException
    {
        System.out.println("Map Parser: Serializing Map to "+serialized_file);
        ObjectOutputStream out = new ObjectOutputStream( new FileOutputStream(serialized_file));
        out.writeObject(MAX_ZOOM_LEVEL);
        out.writeObject(MAX_X);
        out.writeObject(MAX_Y);
        out.writeObject(CUSTOM_BOUNDING_BOX);
        out.writeObject(MAP);
        out.close();
        System.out.println("Map Parser: Map Serialization Successful");
    }
    
    public static void parseSerializedMap(String serialized_file) throws IOException, ClassNotFoundException
    {
        System.out.println("Map Parser: Parsing Serialized Map");
        ObjectInputStream in = new ObjectInputStream( new FileInputStream( serialized_file));
        MAX_ZOOM_LEVEL = (int) in.readObject();
        MAX_X = (int) in.readObject();
        MAX_Y = (int) in.readObject();
        CUSTOM_BOUNDING_BOX = (BoundingBox) in.readObject();
        MAP = (Tile) in.readObject();
        in.close();
        System.out.println("Map Parser: Map Parsing Complete");
    }
    
    public static void parseMap(String edge_file) throws IOException
    {
        MAX_ZOOM_LEVEL=MAX_ZOOM_LEVEL_DEFAULT;
        MAX_X=MAX_X_DEFAULT;
        MAX_Y=MAX_Y_DEFAULT;
        MAP=null;
        CUSTOM_BOUNDING_BOX=null;
        
        System.out.println("Started Map Parser for map: "+edge_file);
        readMap(edge_file);
        BoundingBox init_bb;
        if(CUSTOM_BOUNDING_BOX==null)
            init_bb = findInitBoundingBox();
        else
        {
            System.out.println("Map Parser: Setting Custom Initial Bounding Box "+CUSTOM_BOUNDING_BOX);
            init_bb = CUSTOM_BOUNDING_BOX;
        }
        
        System.out.println("Map Parser: Generating tiles");
        MAP = new Tile(0, 0, 0, 0, 0, init_bb);
        generateTiles(MAP);
        cleanLists();
        System.out.println("Map Parser: Finished generating tiles");
    }
    
    public static Tile queryTileByBoundingBox(double minLat, double minLong, double maxLat, double maxLong)
    {
        return queryTile(MAP, new BoundingBox(minLat, minLong, maxLat, maxLong), MAX_ZOOM_LEVEL);
    }
    
    public static Tile queryTileByZoomAndBoundingBox(int zoomLevel, double minLat, double minLong, double maxLat, double maxLong)
    {
        return queryTile(MAP, new BoundingBox(minLat, minLong, maxLat, maxLong), zoomLevel);
    }
    
    public static Tile queryTileByZoomAndPoint(int zoomLevel, double Lat, double Long)
    {
        return queryTile(MAP, new BoundingBox(Lat, Long, Lat, Long), zoomLevel);
    }
    
    public static void generateSubMapCSV(Tile parent, OutputStream out_nodes, OutputStream out_edges) throws IOException
    {
        
        String line;
    
        if(parent.crossWays!=null)
        {
            for(Way w: parent.crossWays)
            {
                line = w.wid + ", " + w.from.vid + ", " + w.to.vid + ", " + w.length_km + ", 0, 0, None\n";
                out_edges.write(line.getBytes());
            }
        }

        if (parent.zoomLevel == MAX_ZOOM_LEVEL && parent.vertices!=null)
        {
            for(Vertex v: parent.vertices)
            {
                line = v.vid + ", , " + v.Lat + ", " + v.Long + "\n";
                out_nodes.write(line.getBytes());
            }
         }
        else if(parent.subTiles!=null)
            for(Tile subTile: parent.subTiles)
                generateSubMapCSV(subTile, out_nodes, out_edges);
     }
    
    public static int getMaximumZoomLevel()
    {
        return MAX_ZOOM_LEVEL;
    }
    
    //Private Functions
    
    private static void generateTiles(Tile parent)
    {
        
        if(parent.zoomLevel < MAX_ZOOM_LEVEL)
        {
            parent.subTiles = new ArrayList<>();
            
            int zoomLevel = parent.zoomLevel+1;
        
            BoundingBox parent_bb = parent.boundBox;
        
            double [] global_span = Comparison.global_span(
                    MAP.boundBox.minLat, MAP.boundBox.minLong, MAP.boundBox.maxLat, MAP.boundBox.maxLong,
                    MAX_X+1, MAX_Y+1, zoomLevel
            );
                    
            double[] local_span = Comparison.local_span(
                    parent.boundBox.minLat, parent.boundBox.minLong, parent.boundBox.maxLat, parent.boundBox.maxLong,
                    MAX_X+1, MAX_Y+1
            );
        
            for(int x=0; x<=MAX_X; x++)
            {
                for(int y=0; y<=MAX_Y; y++)
                {
                    
                    double minLong = parent_bb.minLong + x*local_span[1];
                    double minLat = parent_bb.minLat + y*local_span[0];
                
                    BoundingBox bbox = new BoundingBox(minLat, minLong, minLat+local_span[0], minLong+local_span[1]);
                    
                    int[] global_index = Comparison.global_index(minLat, minLong, MAP.boundBox.minLat, MAP.boundBox.minLong, global_span);
                    
                    Tile tile = new Tile(zoomLevel,  global_index[1], global_index[0], x, y, bbox);
                    parent.subTiles.add(tile);
                    generateTiles(tile);
                }
            }
        }
        else
            addVertices(parent);
        
        addCrossWays(parent);
        
    }
    
    private static void addCrossWays(Tile parent)
    {
        parent.crossWays = new ArrayList<>();
        
        int index=0;
        
        while(index<WayList.wayList.size())
        {
            Way w = WayList.wayList.get(index);
            if(doesLie(w, parent.boundBox))
            {
                parent.crossWays.add(w);
                WayList.wayList.remove(index);
            }
            else
                index++;
        }
    }
    
    private static void addVertices(Tile parent)
    {
        parent.vertices = new ArrayList<>();
        
        int index=0;
        
        while(index<VertexList.vlist.size())
        {
            Vertex w = VertexList.vlist.get(index);
            if(doesLie(w, parent.boundBox))
            {
                parent.vertices.add(w);
                VertexList.vlist.remove(index);
            }
            else
                index++;
        }
    }
    
    private static boolean isChild(BoundingBox bbox_child, BoundingBox bbox_parent)
    {
        if(bbox_parent.minLat<=bbox_child.minLat && bbox_parent.minLong<=bbox_child.minLong && bbox_parent.maxLat>=bbox_child.maxLat && bbox_parent.maxLong>=bbox_child.maxLong)
            return true;
        return false;
    }
    
    private static boolean doesLie(Way way, BoundingBox bbox)
    {
        return doesLie(way.from, bbox) && doesLie(way.to, bbox);
    }
    
    private static boolean doesLie(Vertex point, BoundingBox bbox)
    {
        if(point.Lat>=bbox.minLat && point.Lat<=bbox.maxLat && point.Long>=bbox.minLong && point.Long<=bbox.maxLong)
            return true;
        return false;
    }
    
    private static BoundingBox findInitBoundingBox()
    {
        System.out.println("Map Parser: Finding Initial Bounding Box");
        
        double minLat=Double.MAX_VALUE, minLong=Double.MAX_VALUE, maxLong=Double.MIN_VALUE, maxLat=Double.MIN_VALUE;
        
        for(Vertex v: VertexList.vlist)
        {
            double Lat=v.Lat;
            double Long=v.Long;
            
            if(Lat<minLat)
                minLat=Lat;
            else if(Lat>maxLat)
                maxLat=Lat;
            
            if(Long<minLong)
                minLong=Long;
            else if(Long>maxLong)
                maxLong=Long;
        }
        
        System.out.println("Map Parser: Found Initial Bounding Box ("+minLat+", "+minLong+", "+maxLat+", "+maxLong+")");
        
        return new BoundingBox(minLat, minLong, maxLat, maxLong);
    }

    private static void readMap( String fname) throws IOException
    {
        System.out.println("Map Parser: Reading Map");
        VertexList.vlist = new ArrayList<>();
        Scanner reader = new Scanner( new FileInputStream( fname));
        
        String line;
        String[] tokens;
        
        while(reader.hasNext())
        {
            line = reader.nextLine().trim().toLowerCase();

            //Comment
            if(line.charAt(0)=='#')
                continue;
            
            //Parser Directive
            if(line.charAt(0)=='@')
            {
                tokens = line.split(":|,");
                
                switch(tokens[0].trim())
                {
                    case "@boundingbox":
                        System.out.print("Map Parser: Detected Custom Bounding Box ");
                        CUSTOM_BOUNDING_BOX = new BoundingBox(
                        Double.parseDouble(tokens[1].trim()),
                        Double.parseDouble(tokens[2].trim()),
                        Double.parseDouble(tokens[3].trim()),
                        Double.parseDouble(tokens[4].trim()));
                        System.out.println(CUSTOM_BOUNDING_BOX);
                    break;
                    
                    case "@maximumzoomlevel":
                        System.out.print("Map Parser: Setting Maximum Zoom Level to ");
                        MAX_ZOOM_LEVEL = Integer.parseInt(tokens[1].trim());
                        System.out.println(MAX_ZOOM_LEVEL);
                    break;
                    
                    case "@span":
                        System.out.println("Map Parser: Setting Tile Span to "+tokens[1].trim());
                        tokens = tokens[1].trim().split("x");
                        MAX_X = Integer.parseInt(tokens[0])-1;
                        MAX_Y = Integer.parseInt( tokens[1])-1;
                    break;
                    
                    default:
                        System.out.println("Map Parser: Ignoring Unknown Parser Directive '"+tokens[0]+"'");
                }
                
                continue;
            }
            
            tokens = line.split(",");
            
            double Long1 = Double.parseDouble(tokens[2].trim());
            double Lat1 = Double.parseDouble(tokens[3].trim());
            double Long2 = Double.parseDouble(tokens[4].trim());
            double Lat2 = Double.parseDouble(tokens[5].trim());
            
            Vertex v1 = VertexList.add(Lat1, Long1);
            Vertex v2 = VertexList.add(Lat2, Long2);
            WayList.add(v1,v2, Double.parseDouble( tokens[1]));
        }
        
        reader.close();
        System.out.println("Map Parser: Map Reading Complete");
    }
 
    private static Tile queryTile( Tile parent, BoundingBox bbox, int max_zoom_level)
    {
        if(parent==null)
            return null;
        
        if(!isChild(bbox, parent.boundBox))
            return null;
        
        if(parent.zoomLevel < max_zoom_level)
        {
            for(Tile subTile: parent.subTiles)
            {
                Tile tile = queryTile(subTile, bbox, max_zoom_level);
            
                if(tile!=null)
                    return tile;
            }
        }
        
        return parent;
    }

    private static void cleanLists()
    {
        VertexList.vlist = null;
        WayList.wayList = null;
    }
    
    //Public Classes
    
    public static class BoundingBox implements Serializable
    {
        public final double minLat;
        public final double minLong;
        public final double maxLat;
        public final double maxLong;
    
        public BoundingBox(double minLat, double minLong, double maxLat, double maxLong)
        {
            this.minLat=minLat;
            this.minLong=minLong;
            this.maxLat=maxLat;
            this.maxLong=maxLong;
        }
        
        @Override
        public String toString()
        {
            return minLat+", "+minLong+", "+maxLat+", "+maxLong;
        }
    }
    
    public static class Tile implements Serializable
    {
        public final BoundingBox boundBox;
        
        public final int zoomLevel;
        public final int globalX;
        public final int globalY;
        public final int localX;
        public final int localY;
        
        private ArrayList<Way> crossWays;
        
        private ArrayList<Vertex> vertices;
        
        private ArrayList<Tile> subTiles;
        
        public Tile(int zoomLevel, int globalX, int globalY, int localX, int localY, BoundingBox boundBox)
        {
            this.boundBox = boundBox;
            this.globalX = globalX;
            this.globalY = globalY;
            this.localX = localX;
            this.localY = localY;
            this.zoomLevel = zoomLevel;
            this.vertices = null;
            this.crossWays = null;
            this.subTiles=null;
        }
        
        public ArrayList<Way> crossWays()
        {
            return crossWays;
        }
        
        public ArrayList<Vertex> vertices()
        {
            return vertices;
        }
        
        public ArrayList<Tile> subTiles()
        {
            return subTiles;
        }
    }

    public static class Vertex implements Serializable
    {
        public final int vid;
        public final double Lat;
        public final double Long;
    
        public Vertex( int vid, double Lat, double Long)
            
        {
            this.vid=vid;
            this.Lat=Lat;
            this.Long=Long;
        }
    }

    public static class Way implements Serializable
    {
        public final int wid;
        public final Vertex from;
        public final Vertex to;
    
        public final double length_km;
    
        public Way(int wid, Vertex from, Vertex to, double length_km)
        {
            this.wid = wid;
            this.from = from;
            this.to = to;
            this.length_km=length_km;
        }
    }

    
    //Private Classes
    
    private static class VertexList
    {
        public static ArrayList<Vertex> vlist = new ArrayList<>();
    
        public static Vertex add(double Lat, double Long)
        {
            int search = vertexExists(Lat,Long);
        
            if(search==-1)
            {
                vlist.add(new Vertex(vlist.size(), Lat, Long));
                search=vlist.size()-1;
            }
        
            return vlist.get(search);
        }
    
        public static int vertexExists(double Lat, double Long)
        {
            for(Vertex v: vlist)
                if(Comparison.equal(v.Lat,Lat)&&Comparison.equal(v.Long,Long))
                    return v.vid;
            return -1;
        }
    }
    
    private static class WayList
    {
        public static ArrayList<Way> wayList = new ArrayList<>();
    
        public static void add(Vertex v1, Vertex v2, double length_km)
        {
            wayList.add(new Way(wayList.size(), v1, v2, length_km));
        }
    }

}
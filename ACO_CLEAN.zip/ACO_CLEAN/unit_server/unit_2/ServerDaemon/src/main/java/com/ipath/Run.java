package com.ipath;
public class Run {
    
    public static void main(String[] args) throws InterruptedException
    {
        ServerDaemons server = new ServerDaemons();
        server.start();
        server.join();
    }
}

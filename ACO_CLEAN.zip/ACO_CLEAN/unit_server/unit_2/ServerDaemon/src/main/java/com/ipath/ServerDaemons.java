package com.ipath;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileInputStream;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.HashMap;

import com.ipath.parser.MapParsingService;
import com.ipath.parser.MapParsingService.Tile;
import com.ipath.parser.UserDatabaseParsingService;
import com.ipath.parser.UserDatabaseParsingService.User;
import com.ipath.parser.math.Comparison;
import com.ipath.io.IO;


public class ServerDaemons extends Thread {

    public static final int MAJOR_SERVER_DAEMON_PORT = 3000;
    public static final int MAX_CLIENTS = 4;
    public static final int MAX_SERVICES_PER_CLIENT = 2;
    public static final int MAJOR_DAEMON_TIMEOUT = 10000;
    public static final int MINOR_DAEMON_TIMEOUT = 10000;
    public static final int MAX_BUFFER_SIZE=1048576;
    
    public static final String VERSION="1.0";
    public static final String MAP_FILE="/home/ghost/Desktop/ACO/source/maps/processed/india_road_edges.csv";
    public static final String MAP_DIR="/home/ghost/Desktop/ACO/exported/";
    public static final String USER_DB_FILE = "/home/ghost/Desktop/ACO/userdb.csv";
    
    public static final String MSG_SERV_UNAVAIL_OVERLOAD = 
            "Status: Request Denied by Major Daemon.\nReason: Overloaded Server. Try again later.\n";
    public static final String MSG_SERV_REQ_ACCEPT =
            "Status: Request Accepted by Major Daemon.\nPort Alloted: ";
    public static final String MSG_SERV_REQ_ACCEPT_NUMBER =
            "Services Accepted: ";
    public static final String MSG_SERV_LOGIN_SUCCESS =
            "Status: Login Successful\n";
    public static final String MSG_SERV_ALREADY_LOGGED_IN =
            "Status: Already Logged In\n";
    public static final String MSG_SERV_NO_SUCH_USER_EXISTS =
            "Status: No Such User Exists\n";
    public static final String MSG_SERV_WRONG_CREDENTIALS =
            "Status: Incorrect Credentials\n";
    public static final String MSG_SERV_REGISTER_SUCCESS = 
            "Status: Registration Successful\n";
    public static final String MSG_SERV_REGISTER_FAIL =
            "Status: Registration Failed\n";
    public static final String MSG_SERV_UNREGISTER_SUCCESS =
            "Status: Unregistration Successful\n";
    public static final String MSG_SERV_UNREGISTER_FAIL =
            "Status: Unregistration Failed\n";
    public static final String MSG_SERV_PROP_CHANGE_FAIL =
            "Status: Property Change Successful\n";
    public static final String MSG_SERV_PROP_CHANGE_SUCCESS =
            "Status: Property Change Failed\n";
    public static final String MSG_SERV_LOGOUT =
            "Status: Logout Successful";
    public static final String MSG_SERV_NOT_LOGGED_IN =
            "Status: Login required before servicing";
    
    private static boolean HALT=false;
    private static int CLIENTS_CONNECTED=0;
    
    private static ArrayList<MinorDaemon> MINOR_DAEMONS;
    
    private static final HashMap<String, User> LOGGED_IN_CLIENTS = new HashMap<>();
    
    /* Major Daemon */
    @Override
    public void run() {
        
        try
        {
            System.out.println("Starting Major Daemon v"+VERSION);
            
            //Parsing Map File
            if(new File(MAP_FILE.split(".csv$")[0]+".serialized").exists())
                MapParsingService.parseSerializedMap(MAP_FILE.split(".csv$")[0]+".serialized");
            else
            {
                MapParsingService.parseMap(MAP_FILE);
                MapParsingService.serializeParsedMap(MAP_FILE.split(".csv$")[0]+".serialized");
            }
            
            //Parsing User Database
            if(new File(USER_DB_FILE.split(".csv$")[0]+".serialized").exists())
                UserDatabaseParsingService.parseSerializedUserDatabase(USER_DB_FILE.split(".csv$")[0]+".serialized");
            else
            {
                UserDatabaseParsingService.parseUserDatabase(USER_DB_FILE);
                UserDatabaseParsingService.serializeParsedUserDatabase(USER_DB_FILE.split(".csv$")[0]+".serialized");
            }
            
            ServerSocket publicPort = new ServerSocket(MAJOR_SERVER_DAEMON_PORT);
            
            MINOR_DAEMONS = new ArrayList<>();
            
            System.out.println("Major Daemon Started.");
            
            while(!HALT)
            {
                try
                {
                    publicPort.setSoTimeout(MAJOR_DAEMON_TIMEOUT);
                    System.out.println("Major Daemon Status: IDLE, Listening for Clients");
                    Socket clientConnection = publicPort.accept();
                    System.out.println("Major Daemon Status: Client Connection Accepted");
                
                    InputStream in = clientConnection.getInputStream();
                    Scanner reader = new Scanner(in);
                
                    ArrayList<String> servicesRequested = new ArrayList<>();
                    int number_of_services = Integer.parseInt(reader.nextLine());
                    while(servicesRequested.size()<MAX_SERVICES_PER_CLIENT && servicesRequested.size()<number_of_services && reader.hasNext())
                    servicesRequested.add(reader.nextLine());
                
                    MinorDaemon privateDaemon = createMinorDaemon(servicesRequested);
                
                    OutputStream out = clientConnection.getOutputStream();
                    PrintWriter writer = new PrintWriter(out, true);
                
                    if(privateDaemon==null)
                        writer.println(MSG_SERV_UNAVAIL_OVERLOAD);
                    else
                    {
                        writer.println(MSG_SERV_REQ_ACCEPT + privateDaemon.getLocalPort());
                        writer.println(MSG_SERV_REQ_ACCEPT_NUMBER + servicesRequested.size());
                    }

                    clientConnection.close();
                    System.out.println("Major Daemon Status: Client serviced.");
                }
                catch(SocketTimeoutException exc1)
                {
                    System.out.println("Major Daemon Status: Timed out");
                }
            }
        }
        catch(IOException exc2){
            System.err.println("Error: Unable to start Major Server Daemon.");
        }
        catch(ClassNotFoundException exc3){
            System.err.println("Eror: Class Not Found");
        }
        
        try
        {
            UserDatabaseParsingService.serializeParsedUserDatabase(USER_DB_FILE);
        }
        catch(IOException ioe){
            System.err.println("Error: Unable to save user database.");
        }
        
        System.out.println("Major Daemon Exited.");
        System.exit(0);
    }

    private static MinorDaemon createMinorDaemon(ArrayList<String> servicesRequested) {
    
        if(CLIENTS_CONNECTED == MAX_CLIENTS)
                return null;
        
        while(true)
        {
            try
            {
                ServerSocket servsocket = new ServerSocket(1000+((int)(Math.random()*(Short.MAX_VALUE-1000))));
                MinorDaemon daemon = new MinorDaemon(servsocket, servicesRequested, CLIENTS_CONNECTED++);
                
                MINOR_DAEMONS.add(daemon);
                
                daemon.start();
                
                return daemon;
            }
            catch(IOException exc){
            }
        }
    }
    
    static class MinorDaemon extends Thread
    {
        private ServerSocket server;
        private ArrayList<String> servicesRequested;
        private int id;
        private byte[] buffer;
        
        public MinorDaemon(ServerSocket server, ArrayList<String> servicesRequested, int id)
        {
          this.server = server;
          this.servicesRequested = servicesRequested;
          this.id = id;
          this.buffer = new byte[MAX_BUFFER_SIZE];
        }
        
        @Override
        public void run()
        {
            try
            {
                System.out.println("Started Minor Daemon #"+id);
                server.setSoTimeout(MINOR_DAEMON_TIMEOUT);
                System.out.println("Minor Daemon #"+id+" Status: IDLE, Waiting for Client");
                Socket clientConnection = server.accept();
                System.out.println("Minor Daemon #"+id+" Status: Client Connected, Servicing the Client");
                //Client Services offered here.
                serviceClient(clientConnection);
                if(!clientConnection.isClosed())
                    clientConnection.close();
                System.out.println("Minor Daemon #"+id+" Status: Client Serviced");
            }
            catch(SocketTimeoutException exc1)
            {
                System.err.println("Error: Minor Daemon #"+id+" timed out at port "+server.getLocalPort());
            }
            catch(IOException exc2)
            {
                System.err.println("Error: Failed to accept client connection at port "+server.getLocalPort());
            }
            finally
            {
                try
                {
                    server.close();
                }
                catch(IOException exc3)
                {
                    System.err.println("Error: Unable to close Minor Socket #"+id+" at port "+server.getLocalPort());
                }
            }
            
            System.out.println("Minor Daemon #"+id+" Exited");
            CLIENTS_CONNECTED--;
        }
        
        public int getLocalPort()
        {
            return server.getLocalPort();
        }
        
        //Services Client
        private void serviceClient(Socket clientSocket) throws IOException
        {
            InputStream in = clientSocket.getInputStream();
            OutputStream out = clientSocket.getOutputStream();
            String ip = clientSocket.getRemoteSocketAddress().toString().split(":")[0];
            boolean logged_in = LOGGED_IN_CLIENTS.containsKey(ip);
            
            if(!logged_in && !servicesRequested.get(0).equals("request_login"))
            {
                out.write(MSG_SERV_NOT_LOGGED_IN.getBytes());
                return;
            }
            
            for(String service: servicesRequested)
            {
                service=service.toLowerCase();
                
                switch(service)
                {
                    case "fetch_tile_image":
                        fetchTileImage(in, out, buffer);
                        break;
                        
                    case "request_login":
                        requestLogin(in, out, ip);
                        break;
                    
                    case "request_logout":
                        requestLogout(out, ip);
                        break;
                    
                    case "register_user":
                        registerUser(in,out);
                        break;
                     
                    case "unregister_user":
                        unregisterUser(in, out, ip);
                        break;
                    
                    case "change_user_property":
                        changeUserProperty(in, out, ip);
                        break;
                    
                    default:
                        break;
                }
            }
        }
    }
    
    public void halt()
    {
        HALT=true;
    }
    
    
    //Services
    
    /* 
     * Service: Fetches a Tile Image
     * Description: Fetches a tile image of a specified region.
     * Request Format: <zoomFlag>\n<zoomLevel>\n<minLat>\n<minLong>\n<maxLat>\n<maxLong>
    */
    public static void fetchTileImage(InputStream in, OutputStream out, byte[] buffer) throws IOException
    {
        Scanner reader = new Scanner(in);
        
        boolean zoomFlag = reader.nextBoolean();
        int zoomLevel = MapParsingService.getMaximumZoomLevel();
        
        if(zoomFlag)
            zoomLevel = reader.nextInt();
        
        double minLat = reader.nextDouble();
        double minLong = reader.nextDouble();
        double maxLat = reader.nextDouble();
        double maxLong = reader.nextDouble();

        
        Tile tile = MapParsingService.queryTileByZoomAndBoundingBox(zoomLevel, minLat, minLong, maxLat, maxLong);
        String img_file = MAP_DIR+"t"+zoomLevel+"."+tile.globalX+"."+tile.globalY+".png";
        FileInputStream fin = new FileInputStream(img_file);
        
        long length = new File(img_file).length();
        
        //Converting File Length to Bytes: Big Endian and writing to the outputstream
        out.write(Comparison.getBytes(length));
        
        //Transfering the tile securely
        IO.secureTransferStream(buffer, length, fin, out);
        
        fin.close();
    }
    
    
    public static void requestLogin( InputStream in, OutputStream out, String ip) throws IOException
    {
        Scanner reader = new Scanner(in);
        String username = reader.nextLine();
        String password = reader.nextLine();
        String message;
        if(LOGGED_IN_CLIENTS.get(ip)!=null)
            message = MSG_SERV_ALREADY_LOGGED_IN;
        else
        {
            User user = UserDatabaseParsingService.findUser(username);
            
            if(user==null)
                message = MSG_SERV_NO_SUCH_USER_EXISTS;
            else
            {
                if(user.matchPassword(password))
                {
                    LOGGED_IN_CLIENTS.put(ip, user);
                    message = MSG_SERV_LOGIN_SUCCESS;
                }
                else
                    message = MSG_SERV_WRONG_CREDENTIALS;
            }
        }
        
        int length = message.length();
        
        //Converting length to Bytes: Big Endian and writing to the outputstream
        out.write(Comparison.getBytes(length));
        
        //Writing the message
        out.write(message.getBytes());
    }
    
    public static void registerUser( InputStream in, OutputStream out) throws IOException
    {
        Scanner reader = new Scanner(in);
        String unam = reader.nextLine();
        String upwd = reader.nextLine();
        String nam = reader.nextLine();
        String mail = reader.nextLine();
        String phon = reader.nextLine();
        String addr = reader.nextLine();
        
        String message;
        
        if(UserDatabaseParsingService.addUser(unam, upwd, nam, mail, phon, addr))
            message = MSG_SERV_REGISTER_SUCCESS;
        else
            message = MSG_SERV_REGISTER_FAIL;
        
        out.write(Comparison.getBytes(message.length()));
        out.write(message.getBytes());
    }
    
    public static void unregisterUser( InputStream in, OutputStream out, String ip) throws IOException
    {
        Scanner reader = new Scanner(in);
        String upwd = reader.nextLine();
        
        User user = LOGGED_IN_CLIENTS.get(ip);
        LOGGED_IN_CLIENTS.remove(ip, user);
        
        String message;
        
        if(UserDatabaseParsingService.removeUser(user.username(), upwd))
            message = MSG_SERV_REGISTER_SUCCESS;
        else
            message = MSG_SERV_REGISTER_FAIL;
        
        out.write(Comparison.getBytes(message.length()));
        out.write(message.getBytes());
    }
    
    public static void changeUserProperty( InputStream in, OutputStream out, String ip) throws IOException
    {
        Scanner reader = new Scanner(in);
        String pwd = reader.nextLine();
        String prop = reader.nextLine();
        String nval = reader.nextLine();
        
        User user = LOGGED_IN_CLIENTS.get(ip);
        LOGGED_IN_CLIENTS.remove(ip, user);
        
        String message;
        
        if(user.changeProperty(pwd, prop, nval))
            message = MSG_SERV_PROP_CHANGE_SUCCESS;
        else
            message = MSG_SERV_PROP_CHANGE_FAIL;
        
        out.write(Comparison.getBytes(message.length()));
        out.write(message.getBytes());
    }
    
    public static void requestLogout(OutputStream out, String ip) throws IOException
    {
        String message = MSG_SERV_LOGOUT;
        LOGGED_IN_CLIENTS.remove(ip);
        out.write(Comparison.getBytes(message.length()));
        out.write(message.getBytes());
    }
    
}

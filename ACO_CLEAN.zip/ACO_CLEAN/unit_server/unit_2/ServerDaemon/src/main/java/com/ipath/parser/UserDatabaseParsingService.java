package com.ipath.parser;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Scanner;

public class UserDatabaseParsingService {
    
    private static HashMap<String, User> USER_DB;
    
    public static boolean addUser(String username, String passwd, String name, String email, String phone, String address)
    {
        if(findUser(username)!=null)
            return false;
        User user = new User(username,passwd, new User.UserInfo(name, email, phone, address));
        USER_DB.put(username, user);
        return true;
    }
    
    public static User findUser(String username)
    {
        return USER_DB.get(username);
    }
    
    public static boolean removeUser(String username, String passwd)
    {
        User user = findUser(username);
        if(user==null || !user.matchPassword(passwd))
            return false;
        return USER_DB.remove(username, user);
    }
    
    public static void serializeParsedUserDatabase(String user_db) throws IOException
    {
        System.out.println("Saving Serialized userdatabase to: "+ user_db); 
        ObjectOutputStream out = new ObjectOutputStream( new FileOutputStream(user_db));
        out.writeObject(USER_DB);
        out.close();
        System.out.println("Serialized userdatabase saved");
    }
    
    public static void parseSerializedUserDatabase(String user_db) throws IOException, ClassNotFoundException
    {
        System.out.println("Parsing Serialized userdatabase from: "+ user_db); 
        ObjectInputStream in = new ObjectInputStream( new FileInputStream(user_db));
        USER_DB = (HashMap<String,User>) in.readObject();
        in.close();
        System.out.println("Parsed Serialized userdatabase");
    }
    
    public static void parseUserDatabase(String user_db) throws IOException
    {
        USER_DB = new HashMap<>();
        
        System.out.println("Started UserDatabase Parser on: "+ user_db);
        Scanner reader = new Scanner( new FileInputStream( user_db));
        
        while(reader.hasNext())
        {
            String line=reader.nextLine().trim();
            
            //Skipping Comment
            if(line.charAt(0)=='#')
                continue;
            
            /* Format: "username", "password", "name", "email", "phone", "address" */
            String fields[] = line.split(",(?=(?:[^'\"`]*(['\"`]).*?\\1)*[^'\"`]*$)");
            
            for(int i=0; i<6; i++)
            {
                fields[i] = fields[i].trim();
                fields[i] = fields[i].substring(1, fields[i].length()-1);
            }
            fields[0]=fields[0].toLowerCase();
            
            User user = new User(fields[0], fields[1], new User.UserInfo(fields[2], fields[3], fields[4], fields[5]));
            USER_DB.put(user.username, user);
        }
        
        reader.close();
        
        System.out.println("Parsed UserDatabase successfully");
        
    }
    
    public static class User implements Serializable
    {
        private final String username;
        private String password;
        private final UserInfo userinfo;
        
        public User( String usernam, String passwd, UserInfo uinf)
        {
            this.username = usernam;
            this.userinfo = uinf;
            this.password = passwd;
        }
        
        public String username()
        {
            return username;
        }
        
        public boolean matchPassword(String pwd)
        {
            return pwd.equals(password);
        }
        
        public boolean changeProperty(String pwd, String property, String nval)
        {
            if(!matchPassword(pwd))
                return false;
            
            if(property.equals("password"))
            {
                password = nval;
                return true;
            }
            else
                return userinfo.change(property, nval);
        }
        
        public UserInfo userInfo()
        {
            return userinfo;
        }
        
        public static class UserInfo implements Serializable
        {
            private String name;
            private String email;
            private String phone;
            private String address;
            
            public UserInfo(String nam, String mail, String phn, String add)
            {
                this.name = nam;
                this.email = mail;
                this.phone = phn;
                this.address = add;
            }
            
            public String name()
            {
                return name;
            }
            
            public String phone()
            {
                return phone;
            }
            
            public String email()
            {
                return email;
            }
            
            public String address()
            {
                return address;
            }
            
            private boolean change(String property, String value)
            {
                switch(property.toLowerCase())
                {
                    case "name":
                        name = value;
                        return true;
                    case "phone":
                        phone = value;
                        return true;
                    case "address":
                        address=value;
                        return true;
                    case "email":
                        email=value;
                        return true;
                    default:
                        return false;
                }
            }
        }
    }
}

package com.ipath.parser.math;

public class Comparison {
    
    public static final double MAX_RELATIVE_ERROR=0.000001;
    
    public static double relative_error(double x, double y)
    {
        double dif=Math.abs(x-y);
        x=Math.abs(x);
        y=Math.abs(y);
        return Math.max(dif/x,dif/y);
    }
    
    public static boolean equal(double x, double y)
    {
        return relative_error(x,y) <= MAX_RELATIVE_ERROR;
    }
    
    
    public static boolean lesser(double x, double y)
    {
        return x<y && !equal(x,y);
    }
    
    public static boolean greater(double x, double y)
    {
        return x>y && !equal(x,y);
    }
    
    public static double[] global_span(double global_minLat, double global_minLong, double global_maxLat, double global_maxLong,
            int spanLat, int spanLong, int zoomLevel)
    {
        return new double[]{
            (global_maxLat-global_minLat)/Math.pow(spanLat, zoomLevel),
            (global_maxLong-global_minLong)/Math.pow(spanLong, zoomLevel)
        };
    }
    
    public static double[] local_span(double local_minLat, double local_minLong, double local_maxLat, double local_maxLong,
            int spanLat, int spanLong)
    {
        return new double[]{
            (local_maxLat-local_minLat)/spanLat,
            (local_maxLong-local_minLong)/spanLong
        };
    }
    
    public static int[] global_index(double Lat, double Long, double global_minLat, double global_minLong, double[] global_span)
    {
        return new int[]{
            (int)((Lat-global_minLat)/global_span[0]),
            (int)((Long-global_minLong)/global_span[1])
        };
    }
    
    public static int[] local_index(double Lat, double Long, double local_minLat, double local_minLong, double[] local_span)
    {
        return new int[]{
            (int)((Lat-local_minLat)/local_span[0]),
            (int)((Long-local_minLong)/local_span[1])
        };
    }
    
    /* Big Endian */
    
    public static byte[] getBytes(int num)
    {
        byte[] bytes = new byte[4];
        for(int i=0; i<4; i++)
        {
            int tmp = num>>8;
            bytes[3-i] = (byte)(num-256*tmp);
            num=tmp;
        }
        return bytes;
    }
    
    public static byte[] getBytes(long num)
    {
        byte[] bytes = new byte[8];
        for(int i=0; i<8; i++)
        {
            long tmp = num>>8;
            bytes[7-i] = (byte)(num-256*tmp);
            num=tmp;
        }
        return bytes;
    }
    
    public static int getInt(byte[] bytes)
    {
        int length=0;
        for(int i=0; i<4; i++)
        {
            int val = (int)bytes[3-i];
            if(val<0)
                val = 256-Math.abs(val);
            length += val<<(8*i);
        }
        
        return length;
    }

    public static long getLong(byte[] bytes)
    {
        long length=0;
        for(int i=0; i<8; i++)
        {
            int val = (int)bytes[7-i];
            if(val<0)
                val = 256-Math.abs(val);
            length += val<<(8*i);
        }
        
        return length;
    }
}

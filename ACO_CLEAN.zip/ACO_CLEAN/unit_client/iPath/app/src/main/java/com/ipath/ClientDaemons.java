package com.ipath;

import com.ipath.io.IO;
import com.ipath.math.Comparison;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class ClientDaemons extends Thread {

    public static final String VERSION = "1.0";

    public final String SERV_INET_ADDR;
    public final int SERV_PORT;
    public final int MAX_BUFFER_SIZE;
    public final long SLEEP_DURATION;

    private boolean HALT = false;
    private boolean BUSY = false;

    private byte[] BUFFER;

    private Handle REQUEST_HANDLE;

    private String readToken(InputStream in, char delim) throws IOException
    {
        char c;
        String line="";
        while((c=(char)in.read())!=delim)
            line+=c;
        return line;
    }

    private String readLine(InputStream in) throws IOException
    {
        return readToken(in,'\n');
    }

    public ClientDaemons()
    {
        SERV_INET_ADDR = ConfigurationParser.get("@serverinetaddress").get(0).toString();
        MAX_BUFFER_SIZE = Integer.parseInt(ConfigurationParser.get("@maximumbuffersize").get(0));
        BUFFER = new byte[MAX_BUFFER_SIZE];
        SLEEP_DURATION = Integer.parseInt(ConfigurationParser.get("@threadsleepduration").get(0));
        SERV_PORT = Integer.parseInt(ConfigurationParser.get("@serverpublicport").get(0));
    }

    @Override
    public void run()
    {
        try {
            while (!HALT) {

                while (REQUEST_HANDLE == null)
                    Thread.currentThread().sleep(SLEEP_DURATION);

                try
                {
                    Socket sock = new Socket(SERV_INET_ADDR, SERV_PORT);

                    OutputStream out = sock.getOutputStream();
                    InputStream in = sock.getInputStream();

                    //Sending request to the major daemon at public port
                    out.write(REQUEST_HANDLE.SERVICES.getBytes());

                    //Reading response
                    String confirm = readLine(in).toLowerCase();
                    if(!confirm.contains("accepted"))
                        continue;

                    //Request accepted, get the allocated private port
                    int priv_port = Integer.parseInt( readLine(in).split(":")[1].trim());

                    /* MAJOR ASSUMPTION: ASSUMING ALL REQUESTED SERVICES ALLOTED : CHANGE CODE LATER */

                    sock = new Socket(SERV_INET_ADDR, priv_port);

                    out = sock.getOutputStream();
                    in = sock.getInputStream();

                    //Sending service parameters to minor daemon at private port
                    if(REQUEST_HANDLE.PARAM_SERV != null)
                        out.write(REQUEST_HANDLE.PARAM_SERV.getBytes());

                    //Reading the service result and servicing the handle
                    serviceRequestHandle(in);

                    //Closing the socket and removing the handle
                    if(!sock.isClosed())
                        sock.close();

                    REQUEST_HANDLE=null;
                    BUSY=false;
                }
                catch(IOException exc1)
                {
                    System.err.println("Error: Failed to service the handle, retrying...");
                }
            }
        }
        catch(InterruptedException exc2){
            System.err.println("Error: Client Daemon Interrupted");
        }
    }

    /* Halts the daemon gracefully */
    public void halt()
    {
        HALT=true;
    }

    /* Wait till the daemon is free by continuous polling */
    public void pollingWait()
    {
        while(BUSY);
    }

    /* Wait till the daemon is free by sleeping indefinitely */
    public void sleepingWait() throws InterruptedException
    {
        while(BUSY)
            Thread.currentThread().sleep(SLEEP_DURATION);
    }

    /* Wait till the daemon is free by sleeping for atmost time-out time */
    public void sleepingWait(long timeout) throws InterruptedException
    {
        while(BUSY && (timeout -= SLEEP_DURATION) >= 0)
            Thread.currentThread().sleep(SLEEP_DURATION);

        if(BUSY)
            Thread.currentThread().sleep(timeout);
    }

    /* Returns true if the daemon is busy */
    public boolean isBusy()
    {
        return BUSY;
    }

    //Services Offered

    public synchronized Handle fetchTileImage(int zoomLevel, double[] bound_box, String fout)
    {
        if(BUSY)
            return null;
        BUSY=true;

        String param_serv = "true\n"+zoomLevel+"\n"+bound_box[0]+"\n"+bound_box[1]+"\n"+bound_box[2]+"\n"+bound_box[3]+"\n";
        ArrayList< ArrayList<Object>> param_client = new ArrayList<>();
        ArrayList<Object> param_client_serv1 = new ArrayList<>();
        param_client_serv1.add(fout);
        param_client.add(param_client_serv1);

        Handle handle = new Handle("1\nfetch_tile_image\n", param_client, param_serv);
        REQUEST_HANDLE = handle;

        return handle;
    }

    public synchronized Handle requestLogin( String usernam, String passwd)
    {
        if(BUSY)
            return null;
        BUSY=true;

        String param_serv = usernam+"\n"+passwd+"\n";

        Handle handle = new Handle("1\nrequest_login\n", null, param_serv);
        REQUEST_HANDLE = handle;

        return handle;
    }

    public synchronized Handle requestLogout()
    {
        if(BUSY)
            return null;
        BUSY=true;

        Handle handle = new Handle("1\nrequest_logout\n",null,null);
        REQUEST_HANDLE = handle;

        return handle;
    }

    public synchronized Handle requestRegistration(String unam, String upwd, String nam, String mail, String phn, String add)
    {
        if(BUSY)
            return null;
        BUSY=true;

        String param_serv = unam+"\n"+upwd+"\n"+nam+"\n"+mail+"\n"+phn+"\n"+add+"\n";

        Handle handle = new Handle("1\nregister_user", null, param_serv);
        REQUEST_HANDLE = handle;

        return handle;
    }

    //Request Handle Service Routine

    private void serviceRequestHandle(InputStream in) throws IOException
    {
        int service_id=-2;

        for(String service : REQUEST_HANDLE.SERVICES.split("\n"))
        {
            service_id++;

            if(service_id==-1)
                continue;

            switch(service.toLowerCase())
            {
                case "fetch_tile_image":
                    fetchTileImage(in, service_id);
                    break;
                case "request_login":
                case "request_logout":
                case "register_user":
                    requestLogin$Logout$Register(in, service_id);
                    break;
                case "unregister_user":
                    break;
                case "change_user_property":
                    break;
                default:
                    break;
            }
        }
    }

    //Private Handler Service Routines

    private void fetchTileImage(InputStream in, int id) throws IOException
    {
        //Parsing Length from the stream
        long length=0;
        {
            byte[] bytes = new byte[8];
            IO.secureRead(bytes, in);
            length = Comparison.getLong(bytes);
        }

        //Fetching the Map and Writing it to file
        FileOutputStream fout = new FileOutputStream( REQUEST_HANDLE.PARAM_CLIENT.get(id).get(0).toString());
        IO.secureTransferStream(BUFFER, length, in, fout);
        fout.close();

        //Generating Response Message
        REQUEST_HANDLE.SERV_RESPONSE.add("Fetched Tile Image to: "+REQUEST_HANDLE.PARAM_CLIENT.get(id).get(0));
    }

    private void requestLogin$Logout$Register(InputStream in, int id) throws IOException
    {
        //Parsing Length from the stream
        int length;
        {
            byte[] bytes = new byte[4];
            IO.secureRead(bytes, in);
            length = Comparison.getInt(bytes);
        }

        //Reading Response
        IO.secureRead(BUFFER, 0, length, in);

        //Generating Response Message
        REQUEST_HANDLE.SERV_RESPONSE.add(new String(BUFFER,0, length));
    }

    //Handle Data-structure

    public class Handle
    {
        public final ArrayList<ArrayList<Object>> PARAM_CLIENT;
        public final String PARAM_SERV;
        public final String SERVICES;

        public ArrayList<Object> SERV_RESPONSE;

        public Handle(String services, ArrayList<ArrayList<Object>> param_client, String param_serv)
        {
            this.SERVICES = services;
            this.PARAM_CLIENT = param_client;
            this.PARAM_SERV = param_serv;
            this.SERV_RESPONSE = new ArrayList<>();
        }
    }


    //Static Attributes

    public static ClientDaemons CLIENT_DAEMONS;

    //Static Methods

    public static void START()
    {
        CLIENT_DAEMONS = new ClientDaemons();
        CLIENT_DAEMONS.start();
    }

    public static void HALT()
    {
        CLIENT_DAEMONS.halt();
    }
}

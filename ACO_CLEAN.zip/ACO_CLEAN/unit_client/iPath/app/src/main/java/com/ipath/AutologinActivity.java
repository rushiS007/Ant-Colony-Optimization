package com.ipath;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class AutologinActivity extends AppCompatActivity {

    @Override
    protected void onCreate( Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autologin);

        String usernam = ConfigurationParser.get("@username").get(0);
        String passwd = ConfigurationParser.get("@password").get(0);

        ClientDaemons.Handle handle = ClientDaemons.CLIENT_DAEMONS.requestLogin(usernam, passwd);

        Thread thread = new Thread()
        {
            @Override
            public void run()
            {
                try {
                    while (handle.SERV_RESPONSE.size() == 0)
                        Thread.sleep(ClientDaemons.CLIENT_DAEMONS.SLEEP_DURATION);
                }
                catch (InterruptedException exc){}

                Log.d("MY_MESS","*");
                complete(handle);
            }
        };

        thread.start();
    }

    private void complete(ClientDaemons.Handle handle)
    {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.putExtra("SERV_RESPONSE", handle.SERV_RESPONSE.get(0).toString());
        setResult(1025, intent);
        finish();
    }

    @Override
    public void onBackPressed()
    {
    }
}

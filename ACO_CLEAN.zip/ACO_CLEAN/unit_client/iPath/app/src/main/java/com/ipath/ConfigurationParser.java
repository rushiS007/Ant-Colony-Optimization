package com.ipath;

import android.util.Log;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Scanner;

public class ConfigurationParser {

    private static HashMap<String, ArrayList<String>> FIELD_TAB;

    public static void parseConfigurationsFile(String cfg) throws IOException
    {
        FIELD_TAB = new HashMap<>();

        Scanner reader = new Scanner( new FileInputStream( cfg));

        while(reader.hasNext())
        {
            String line = reader.nextLine();
            if(line.charAt(0)!='@')
                continue; //Comment or Unrecognized format: Skip it

            String tokens[] = line.split(":",2);

            String key = tokens[0].trim().toLowerCase();
            String value = tokens[1].trim();
            ArrayList<String> fieldList = new ArrayList<>();
            String [] fieldValues=value.split(",(?=(?:[^'\"`]*(['\"`]).*?\\1)*[^'\"`]*$)");

            for(int i=0; i<fieldValues.length; i++)
            {
                fieldValues[i] = fieldValues[i].trim();
                if(fieldValues[i].charAt(0)=='\"' || fieldValues[i].charAt(0)=='\'')
                    fieldValues[i]=fieldValues[i].substring(1,fieldValues[i].length()-1);
                else
                    fieldValues[i]=fieldValues[i].replaceAll(" ", "").toLowerCase();
                fieldList.add(fieldValues[i]);
            }

            FIELD_TAB.put(key, fieldList);
        }

        reader.close();
    }

    public static ArrayList<String> get(String field)
    {
        return FIELD_TAB.get(field);
    }
}

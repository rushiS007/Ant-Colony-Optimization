package com.ipath;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LogoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logout);

        ProgressBar progressBar = (ProgressBar) findViewById(R.id.logout_progress);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.animate();

        final ClientDaemons.Handle handle = ClientDaemons.CLIENT_DAEMONS.requestLogout();

        Thread thread = new Thread()
        {
            @Override
            public void run()
            {
                try {
                    while(handle.SERV_RESPONSE.size()==0)
                        Thread.sleep(ClientDaemons.CLIENT_DAEMONS.SLEEP_DURATION);
                    }
                catch ( InterruptedException exc)
                { }

                String response = handle.SERV_RESPONSE.get(0).toString();

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        logout(response);
                    }
                });
            }
        };

        thread.start();
    }

    private void logout(String response)
    {
        Toast.makeText(this, response, Toast.LENGTH_LONG);
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}

package com.ipath;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);


        TextView about_us_text = findViewById(R.id.about_us_text);
        about_us_text.setMovementMethod(new ScrollingMovementMethod());
    }
}

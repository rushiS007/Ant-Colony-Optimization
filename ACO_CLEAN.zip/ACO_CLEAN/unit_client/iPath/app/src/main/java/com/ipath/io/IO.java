package com.ipath.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class IO
{
    public static void secureRead(byte[] buffer, int offset, int length, InputStream in) throws IOException
    {
        int toBeRead = length;
        while(toBeRead>0)
            toBeRead-=in.read(buffer, offset+length-toBeRead, toBeRead);
    }

    public static void secureRead(byte[] buffer, InputStream in) throws IOException
    {
        secureRead(buffer, 0, buffer.length, in);
    }

    public static void secureTransfer(byte[] buffer, int offset, int length, InputStream in, OutputStream out) throws IOException
    {
        secureRead(buffer, offset, length, in);
        out.write(buffer, offset, length);
    }

    public static void secureTransfer(byte[] buffer, InputStream in, OutputStream out) throws IOException
    {
        secureTransfer(buffer, 0, buffer.length, in, out);
    }

    public static void secureTransferStream(byte[] buffer, long streamSize, InputStream in, OutputStream out) throws IOException
    {
        while(streamSize >= buffer.length)
        {
            secureTransfer(buffer, in, out);
            streamSize -= buffer.length;
        }
        secureTransfer(buffer, 0, (int)streamSize, in, out);
    }
}
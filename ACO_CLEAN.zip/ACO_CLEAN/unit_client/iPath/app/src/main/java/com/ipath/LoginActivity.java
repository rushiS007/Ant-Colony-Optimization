package com.ipath;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class LoginActivity extends AppCompatActivity {

    private boolean itemSelected=false;
    private boolean loggedIn=false;
    private BroadcastReceiver receiver;
    private boolean attemptedAutologin=false;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        try {
            ConfigurationParser.parseConfigurationsFile(getExternalFilesDir(null).getAbsolutePath() + "/" + getString(R.string.CFG_FILE));
        }
        catch(IOException exc){
            System.err.println("Error! Unable to read configurations");
            System.exit(1);
            return;
        }

        ClientDaemons.START();

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        EditText usernam = findViewById(R.id.user_name);
        EditText password = findViewById(R.id.password);
        TextView login_status = findViewById(R.id.login_status);
        ProgressBar spinner = findViewById(R.id.spinner);
        ImageButton login = findViewById(R.id.button_login);
        TextView signup = findViewById(R.id.register_text);

        usernam.setOnFocusChangeListener(
                new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        onFocusChangeUsername(usernam, hasFocus);
                    }
                }
        );

        password.setOnFocusChangeListener(
                new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        onFocusChangePasword(password, hasFocus);
                    }
                }
        );

        login.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick( View v){
                        itemSelected=true;
                        onLoginClicked(usernam, password, login_status, spinner, login);
                    }
                }
        );

        signup.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick( View v){
                        itemSelected=true;
                        onRegisterClicked();
                    }
                }
        );
    }

    private void onFocusChangeUsername(EditText usernam, boolean hasFocus)
    {
        if(hasFocus)
        {
            itemSelected=true;
            if(usernam.getText().toString().equals("Username"))
                usernam.setText("");
        }
        else
        {
            itemSelected=false;
            if(usernam.getText().toString().equals(""))
                usernam.setText("Username");
        }
    }

    @Override
    public void onResume()
    {
        super.onResume();

        /* Autologin Feature */

        if(!attemptedAutologin && ConfigurationParser.get("@autologin").get(0).equals("enabled"))
        {
            attemptedAutologin=true;
            itemSelected=true;
            Intent intent = new Intent(this, AutologinActivity.class);
            startActivityForResult(intent, 1024);
        }
    }

    private void onFocusChangePasword(EditText passwd, boolean hasFocus)
    {
        if(hasFocus)
        {
            itemSelected=true;
            if(passwd.getText().toString().equals("Password"))
                passwd.setText("");
        }
        else
        {
            itemSelected=false;
            if(passwd.getText().toString().equals(""))
                passwd.setText("Password");
        }
    }

    private void onLoginClicked(EditText usernam, EditText passwd, TextView login_status, ProgressBar spinner, ImageButton login) {
        String username = usernam.getText().toString().toLowerCase();
        String password = passwd.getText().toString();

        login_status.setText("Logging You In!");

        login.setVisibility(View.INVISIBLE);
        spinner.setVisibility(View.VISIBLE);
        spinner.animate();
        ClientDaemons.Handle handle = ClientDaemons.CLIENT_DAEMONS.requestLogin(username, password);

        Thread thread = new Thread() {
            @Override
            public void run() {

                try {
                    ClientDaemons.CLIENT_DAEMONS.sleepingWait();
                }
                catch(InterruptedException exc){}

                ProgressBar spinner = findViewById(R.id.spinner);
                TextView login_status = findViewById(R.id.login_status);

                String respons_string = handle.SERV_RESPONSE.get(0).toString().split(":")[1].trim();

                boolean successful = false;

                switch(respons_string.toLowerCase())
                {
                    case "login successful":
                    case "already logged in":
                        successful = true;
                        break;
                }

                if (successful) {
                    loggedIn = true;
                    login_status.setText("Login Successful");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            onLoginSuccess();
                        }
                    });
                } else {
                    runOnUiThread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    setContentView(R.layout.activity_login);
                                    spinner.setVisibility(View.INVISIBLE);
                                    login.setVisibility(View.VISIBLE);
                                    login_status.setText("Login Unsucessful:\n"+respons_string);
                                    itemSelected = false;
                                }
                            });
                }
            }
        };

        thread.start();
    }

    private void onLoginSuccess()
    {
        Intent intent = new Intent( this, MainActivity.class);
        intent.putExtra("loginstatus","successful");
        startActivity(intent);
        finish();
    }

    private void onRegisterClicked()
    {
        Intent intent = new Intent(this, RegistrationActivity.class);
        startActivityForResult(intent, 960);
    }

    @Override
    protected void onActivityResult(int reqCode, int resCode, Intent data)
    {
        itemSelected=false;

        if(reqCode==1024) //Autologin
        {
            String serv_response = data.getExtras().get("SERV_RESPONSE").toString().split(":")[1].trim();;
            boolean successful = false;

            switch(serv_response.toLowerCase())
            {
                case "login successful":
                case "already logged in":
                    successful = true;
                    break;
            }

            if(successful)
                onLoginSuccess();
            else
            {
                EditText usernam = findViewById(R.id.user_name);
                EditText password = findViewById(R.id.password);
                TextView login_status = findViewById(R.id.login_status);
                ProgressBar spinner = findViewById(R.id.spinner);
                ImageButton login = findViewById(R.id.button_login);
                TextView signup = findViewById(R.id.register_text);

                usernam.setText(ConfigurationParser.get("@username").get(0));
                password.setText(ConfigurationParser.get("@password").get(0));
                spinner.setVisibility(View.INVISIBLE);
                login.setVisibility(View.VISIBLE);
                login_status.setText("Login Unsucessful:\n"+serv_response);
                itemSelected = false;
            }
        }
        else if(reqCode==960) //Registration
        {

        }

        super.onActivityResult(reqCode, resCode, data);
    }
}

package com.ipath;

import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class MenuActivity extends AppCompatActivity {

    boolean itemSelected=false;

    @Override
    protected void onCreate( Bundle savedInstanceState)
    {
        super.onCreate( savedInstanceState);
        setContentView(R.layout.activity_menu);

        ConstraintLayout menu_layout = findViewById(R.id.menu_layout);
        menu_layout.setOnTouchListener(
                new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {

                        if(!itemSelected) {
                            float y = event.getY();
                            onMenuItemTouch(y);
                        }
                        return true;
                    }
                }
        );
    }

    private void onMenuItemTouch(float y)
    {
        itemSelected=true;

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        float height=metrics.heightPixels;

        float r = y/height;

        if(r<=0.15)
        {
            //Nearby Places
            Intent searchAct = new Intent(this, SearchActivity.class);
            searchAct.putExtra("setsrc","My Location");
            searchAct.putExtra("setdst","Nearby Places");
            startActivityForResult(searchAct, 1);
        }
        else if(r<=0.3)
        {
            //Favorite Places
            Intent favAct = new Intent(this, FavoriteActivity.class);
            startActivityForResult(favAct, 2);

        }
        else if(r<=0.45)
        {
            //Logout
            Intent logoutAct = new Intent(this, LogoutActivity.class);
            startActivity(logoutAct);
            finish();
        }
        else if(r<=0.6)
        {
            //Settings
            Intent settingAct = new Intent(this, SettingsActivity.class);
            startActivityForResult(settingAct, 4);
        }
        else if(r<=0.75)
        {
            //About
            Intent aboutAct = new Intent( this, AboutActivity.class);
            startActivityForResult(aboutAct, 5);
        }
        else
            itemSelected=false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        itemSelected=false;
    }
}

package com.ipath;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity
{
    private boolean itemSelected=false;

    private String CACHE_DIR;

    @Override
    protected void onCreate( Bundle savedInstanceState)
    {
        CACHE_DIR = getExternalCacheDir().getAbsolutePath();
        new File(CACHE_DIR+"/tilecache/").mkdirs();

        ClientDaemons.START();

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        Button button_go = findViewById(R.id.button_go);
        Button button_menu = findViewById(R.id.button_menu);
        ImageView map_view = findViewById(R.id.mapView);

        /* Temporary Code */

        ClientDaemons.Handle handle = null;
        try {
            ClientDaemons.CLIENT_DAEMONS.sleepingWait();
            handle = ClientDaemons.CLIENT_DAEMONS.fetchTileImage(0, new double[]{ 28.6139, 77.2090, 29.8543, 77.8880 }, CACHE_DIR+"/tilecache/t0.0.0.png");

            while(handle.SERV_RESPONSE.size()==0)
                Thread.currentThread().sleep(ClientDaemons.CLIENT_DAEMONS.SLEEP_DURATION);

        }
        catch(InterruptedException exc){}

        Bitmap bmp = BitmapFactory.decodeFile(CACHE_DIR+"/tilecache/t0.0.0.png");
        map_view.setImageBitmap(bmp);
        /* End of Temporary Code */

        button_go.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onGoClicked();
                    }
                }
        );

        button_menu.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onMenuClicked();
                    }
                }
        );
    }

    private void onGoClicked()
    {
        itemSelected=true;
        Intent intent = new Intent(this, SearchActivity.class);
        intent.putExtra("setsrc", (String) null);
        intent.putExtra("setdst", (String) null);
        startActivityForResult(intent, 1);
    }

    private void onMenuClicked()
    {
        itemSelected=true;
        Intent intent = new Intent(this, MenuActivity.class);
        startActivityForResult(intent, 2);
    }

    @Override
    public void onBackPressed()
    {
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        itemSelected=false;
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onDestroy() {
        ClientDaemons.HALT();
        try {
            ClientDaemons.CLIENT_DAEMONS.join();
        } catch (InterruptedException exc) {
        }
        super.onDestroy();
    }
}
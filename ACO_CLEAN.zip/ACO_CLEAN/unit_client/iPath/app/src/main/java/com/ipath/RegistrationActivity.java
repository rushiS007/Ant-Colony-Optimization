package com.ipath;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class RegistrationActivity extends AppCompatActivity {

    private  boolean itemSelected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Button register = findViewById(R.id.button_register);
        register.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        itemSelected=true;
                        onRegisterClicked();
                    }
                }
        );
    }

    private void onRegisterClicked()
    {
        EditText unam, pwd, cpwd, nam, mail, phn, add;

        unam = findViewById(R.id.register_username);
        pwd = findViewById(R.id.register_password);
        cpwd = findViewById(R.id.register_confirm_password);
        nam = findViewById(R.id.register_name);
        mail = findViewById(R.id.register_email);
        phn = findViewById(R.id.register_phone);
        add = findViewById(R.id.register_address);

        if(!pwd.getText().toString().equals(cpwd.getText().toString()))
        {
            //Display Passwords do not match

            return;
        }

        ClientDaemons.Handle handle = ClientDaemons.CLIENT_DAEMONS.requestRegistration(unam.getText().toString(), pwd.getText().toString(),
                nam.getText().toString(), mail.getText().toString(), phn.getText().toString(), add.getText().toString());

        Thread thread = new Thread()
        {
            @Override
            public void run()
            {
                try {
                    while (handle.SERV_RESPONSE.size() == 0)
                        Thread.sleep(ClientDaemons.CLIENT_DAEMONS.SLEEP_DURATION);
                }
                catch(InterruptedException exc){}

                complete(handle.SERV_RESPONSE.get(0).toString());
            }
        };

        thread.start();
    }

    private void complete( String serv_response)
    {
        Intent data = new Intent(this, LoginActivity.class);
        data.putExtra("SERV_RESPONSE", serv_response);
        setResult(961, data);
        finish();
    }
}
